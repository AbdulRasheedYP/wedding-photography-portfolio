Adil Mubarak - Free Cinematic LUTs Pack
===========================================
Included in this pack:
1. Adil Mubarak - Warm Golden Hour.cube
2. Adil Mubarak - Moody Film Teal.cube

How to install:
- DaVinci Resolve: Project Settings > Color Management > Open LUT Folder > Copy LUTs > Update Lists
- Adobe Premiere Pro: Lumetri Color > Creative > Look > Browse...
- Final Cut Pro: Custom LUT effect > Choose LUT...

Connect with Adil Mubarak:
Portfolio: https://adilmubarak.com
